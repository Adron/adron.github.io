
Google Container Engine

Container Clusters > https://cloud.google.com/container-engine/docs/clusters/

https://cloud.google.com/container-engine/docs/clusters/operations


https://cloud.google.com/container-engine/docs/quickstart


https://cloud.google.com/container-engine/docs/


https://cloud.google.com/container-engine/docs/clusters/operations#setting_the_default_cluster

The steps
https://github.com/drone-demos/drone-on-kubernetes/blob/master/gke/gke-with-https/install-drone.sh
https://github.com/drone-demos/drone-on-kubernetes/blob/master/gke/gke-with-https/README.md

https://gc-taylor.com/blog/2015/10/27/example-drone-ci-kubernetes-manifests

What is a Cluster @ GCP?
https://cloud.google.com/container-engine/docs/clusters/

https://cloud.google.com/container-engine/docs/

## ATTEMPT

https://github.com/drone-demos/drone-on-kubernetes/blob/master/gke/gke-with-https/install-drone.sh

