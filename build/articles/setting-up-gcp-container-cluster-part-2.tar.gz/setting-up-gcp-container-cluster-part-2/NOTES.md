
Google Container Engine

Container Clusters > https://cloud.google.com/container-engine/docs/clusters/

https://cloud.google.com/container-engine/docs/clusters/operations


https://cloud.google.com/container-engine/docs/quickstart


https://cloud.google.com/container-engine/docs/


https://cloud.google.com/container-engine/docs/clusters/operations#setting_the_default_cluster

The steps
https://github.com/drone-demos/drone-on-kubernetes/blob/master/gke/gke-with-https/install-drone.sh
https://github.com/drone-demos/drone-on-kubernetes/blob/master/gke/gke-with-https/README.md

https://gc-taylor.com/blog/2015/10/27/example-drone-ci-kubernetes-manifests

What is a Cluster @ GCP?
https://cloud.google.com/container-engine/docs/clusters/

https://cloud.google.com/container-engine/docs/

## ATTEMPT

https://github.com/drone-demos/drone-on-kubernetes/blob/master/gke/gke-with-https/install-drone.sh

[Part 1 - Setting up a GCP Container Cluster]()
[Part 2 - Working with a GCP Container Cluster]() 
Part 3 - Setup of Drone.io on a GCP Container Cluster - Currently being written

In the last [blog entry of this series](/articles/setting-up-gcp-container-cluster/) I wrote up, I covered the steps and some of the issues I ran into getting a Google Cloud Container cluster up and running. In this article I'm going to dive into working with that container, specifically via the `gcloud` and `kubectl` commands. I'm assuming prerequisites at this point include `gcloud` and `kubectl` being installed. With `gcloud` also being setup via the `gcloud init` command already.

