---
title: Building a Data Thrashing CLI Tool in Go, Data Generation
author: Adron Hall
date: 2017-12-31 12:26:54
template: article.jade
---
This post follows from the [previous post](/articles/building-cli-data-thrasher/) on building and setup of the data [Thrahser](https://github.com/Adron/thrasher) CLI. That post covers all of the prerequisites and dives into the initial configuration code and CLI setup.



<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>
