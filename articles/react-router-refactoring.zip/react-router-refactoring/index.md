---
title: react router refactoring
author: Adron Hall
date: 2017-05-16 15:52:22
template: article.jade
---
Yesterday I [took a dive into React](http://blog.adron.me/articles/collected-react-starting-points/), got an overview of what it is, then dug a little deeper into some of its components. Today I've dived directly into one of our problem spaces. In this article I've generalized it a bit to provide an example of what I'm aiming to accomplish.

<span class="more"></span>

First there a little about the opening scenario. I've got this project around a web site application we're building. It has an administration screen (shocker!). On that screen there are a number of various sections like; reports, clients, issues, providers, and other things. The various screens are derived around a business that provides services to individual consumers of X service. We've got a number of X React Components and related elements that go into the construction of each admin section and each section has it's appropriate markup and files. On this admin screen, we have an admin.jsx file that has the various grid elements marked up like this.

```javascript
import React from 'react';
import PropTypes from 'prop-types';
import { browserHistory } from 'react-router';
import { Col, Row, Grid, Nav, NavItem, Button } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';

const AdminScreen = ({ children, onMessageChange, user }) =>
    (<Grid fluid>
      <Row>
        <Col sm={2}>
          <Nav bsStyle="pills" stacked>
            <LinkContainer to={{ pathname: '/administration/issues' }}>
              <NavItem>
                Issues
              </NavItem>
            </LinkContainer>
            <LinkContainer to={{ pathname: '/administration/reports' }}>
              <NavItem>
                Reports
              </NavItem>
            </LinkContainer>
            <LinkContainer to={{ pathname: '/administration/clients' }}>
              <NavItem>
                Clients
              </NavItem>
            </LinkContainer>
            <LinkContainer to={{ pathname: '/administration/providers' }}>
              <NavItem>
                Providers
              </NavItem>
            </LinkContainer>
            <LinkContainer to={{ pathname: '/administration/order-templates' }}>
              <NavItem>
                Order Templates
              </NavItem>
            </LinkContainer>
            <LinkContainer to={{ pathname: '/administration/panel-templates' }}>
              <NavItem>
                Panel Templates
              </NavItem>
            </LinkContainer>
            <LinkContainer to={{ pathname: '/administration/templates' }}>
              <NavItem>
                Report Templates
              </NavItem>
            </LinkContainer>
          </Nav>
        </Col>
        <Col sm={10}>
          {children && React.cloneElement(children, {
            onMessageChange,
            user,
          })}
        </Col>
      </Row>
      <Row>
        <Col sm={2} />
        <Col sm={10}>
          <Button onClick={browserHistory.goBack}>Back</Button>
        </Col>
      </Row>
    </Grid>);

AdminScreen.propTypes = {
  children: PropTypes.node,
  onMessageChange: PropTypes.func,
  user: PropTypes.shape({
    displayName: PropTypes.string,
    email: PropTypes.string,
    group: PropTypes.string,
  }),
};

export default AdminScreen;
```

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>
