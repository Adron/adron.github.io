---
title: Elastic Ecosystem
author: Adron Hall
date: 2016-09-01
template: article.jade
---
**Mission: Build a repository that will spin up an Elasticsearch Cluster, Kibana for reports, and the respective network elements needed on Google Cloud using Terraform, Packer, and related tooling.**

*Before diving in, a few topics for context.* The companies behind a lot of these products I'll be using in this how-to have a lot of great efforts underway.

<div class="image float-right">
    ![Elasticsearch](es10x.png)
</div>

<div class="image float-right">
    ![Kibana](kb10x.png)
</div>

Elastic has an effort underway to synchronize the versions on their products to a v5.0. This release is on the horizon and will bring Elasticsearch, Kibana, and other tooling into a synchronized release schedule based on this v5.0 release. There are also many other products within the Elastic Stack that I'd like to include in this blog entry, but alas, that would make this one blog entry the size of a 300 page book. So I'll be sticking to the specifics and maybe I can keep it to just a few parts to complete the stated mission!

<div class="image float-left">
    ![Packer](packer-logo.png)
</div>

<div class="image float-left">
    ![Terraform](terraform-logo.png)
</div>

Hashicorp, the team behind Terraform, Packer, and related tools (like Vagrant) also have a number of efforts underway. Currently [Terraform is on 0.7.2](https://www.terraform.io/) and [Packer is on 0.10.1](https://www.packer.io/).

**For this how-to I'm making a few assumptions and have a few prerequisites.**

1. You'll need installed and know a bit of git, bash, *nix, networking, and have a Google Cloud Account.
2. You currently have Terraform 0.7.2 and Packer 0.10.1 installed.

<span class="more"></span>

Getting down to business, let's get a basic project structure put together. Create folders named *packer* and *scripts*.