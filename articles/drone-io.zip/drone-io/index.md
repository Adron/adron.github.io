---
title: Introduction to Drone.io
author: Adron Hall
date: 2017-1-25
template: article.jade
---
* **Research & Learn**: [Drone.io](https://github.com/drone/drone)
* **Objective**:

I've dived into a new effort to figure out Drone.io, get it running, and if plausible contribute in some way to the project. This was kick started yesterday while speaking with Joachim

<span class="more"></span>




<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>
