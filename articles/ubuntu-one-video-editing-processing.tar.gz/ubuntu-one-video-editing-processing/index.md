---
title: ubuntu one video editing processing
author: Adron Hall
date: 2017-05-30 20:31:30
template: article.jade
---
Alright, first challenge. Video editing. I've been using a selection of video editing and processing tools for a number of years now.

* Adobe Premier Pro
* Adobe Media Encoder
* Adobe Audition (for sound editing)
* Screenflow

These tools have enabled me to put together all the videos I've done for Pluralsight, Udemy, and all the ones I've posted over the years to Vimeo and Youtube. Respectively, the applications I needed to find on Ubuntu have some big shoes to fill. I will add one thing however; I'm no power user video magician ninja guy. I make straight forward videos with some standard transitions and related sound work. So maybe the applications don't have shoes that are *that* big to fill. But if you work in the technology industry and are looking for applications to use on Linux (namely Ubuntu) to put together vlogs, video screencasts, and those types of things, this part of the series should help (hopefully).

<span class="more"></span>

The first two video applications I sat down and took a look at were [Kdenlive](https://kdenlive.org/) and [Lightworks](Lightworks).