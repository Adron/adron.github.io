---
title: Building a Base Docker Image for a Go Service
author: Adron Hall
date: 2016-11-29
template: article.jade
---

![Gopher, Whale, and Friends](docker-friends.png)

I've been building out an image for deployment of my Go application and wanted to get a write up put together, which is what this blog entry is. Enjoy Gophers, any questions, comments, or suggestions please direct them at me [@Adron](https://twitter.com/Adron). Thanks!

<span class="more"></span>
