---
title: bash keyboard mapping
author: Adron Hall
date: 2017-02-01 10:04:59
template: article.jade
---
<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>

http://www.humbug.in/2010/custom-key-bindings-keyboard-shortcuts-in-bash/
http://askubuntu.com/questions/597395/how-to-set-custom-keyboard-shortcuts-from-terminal
http://unix.stackexchange.com/questions/127309/is-it-possible-to-change-the-key-binding-for-completion-in-bash-shell
http://unix.stackexchange.com/questions/10806/how-to-change-previous-next-word-shortcut-in-bash
http://superuser.com/questions/186985/how-can-i-create-keyboard-shortcuts-to-run-commands-in-a-terminal
http://superuser.com/questions/160388/change-bash-shortcut-keys-such-as-ctrl-c
