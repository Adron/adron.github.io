---
title: setting up gcp container cluster extras
author: Adron Hall
date: 2017-02-01 13:48:40
template: article.jade
---
http://addons.drone.io/google_container_registry/

<span class="more"></span>

