---
title: always deploying with jet and codeship
author: Adron Hall
date: 2016-10-31
template: article.jade
---



<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>

https://github.com/codeship

Examples: https://github.com/codeship/codeship-tool-examples

Jet Locally: https://documentation.codeship.com/docker/installation/

February Release: https://blog.codeship.com/introducing-jet-codeships-platform-for-docker/

Jet Tutorial: https://github.com/codeship/jet-tutorial

Local Dev w/ Jet: https://documentation.codeship.com/docker/cli/

Laura Frank -> https://github.com/rheinwein

