---
title: terraform modules
author: Adron Hall
date: 2016-09-09
template: article.jade
---
<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>

**References:**

* [Terraform Modules for Fun & Profit](http://blog.lusis.org/blog/2015/10/12/terraform-modules-for-fun-and-profit/)
* [Terraform Docs: Module Usage](https://www.terraform.io/docs/modules/usage.html)
* [Terraform Docs: Module Usage](https://www.terraform.io/docs/modules/usage.html)
* [Terraform Docs: Modules]
* [Terraform Docs: Module Sources](https://www.terraform.io/docs/modules/sources.html)
* [Terraform Docs: Create Modules](https://www.terraform.io/docs/modules/create.html)
* [Terraform Community Modules](https://github.com/terraform-community-modules)
* [Using Modules in Terraform](http://www.avitzurel.com/blog/2016/01/05/using-modules-in-terraform/)
* [Two Weeks with Terraform](https://charity.wtf/2016/02/23/two-weeks-with-terraform/)
