---
title: terraform kubernetes azure
author: Adron Hall
date: 2017-10-24 15:57:14
template: article.jade
---
<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>
