---
title: HashiConf Trip Day 3 - Conference Day 1 - Presentation Time
author: Adron Hall
date: 2016-09-07
template: article.jade
---
Day 3 of my trip, and day 1 of the conference kicked off calmly. I made a cup of coffee with my [Aeropress](http://www.aerobie.com/product/aeropress/) & props to [Aneel](https://twitter.com/aneel) for planting the idea a bunch of months ago by showing me how he uses it.

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Good morning <a href="https://twitter.com/hashtag/HashiConf?src=hash">#HashiConf</a>. Cheers! <a href="https://t.co/TxfqtBVmCS">pic.twitter.com/TxfqtBVmCS</a></p>&mdash; Λdrøn (@Adron) <a href="https://twitter.com/Adron/status/773545481704124417">September 7, 2016</a></blockquote>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

<span class="more"></span>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">HashiConf 2016 Announcements. <a href="https://t.co/fUmHFxXSOU">https://t.co/fUmHFxXSOU</a></p>&mdash; Mitchell Hashimoto (@mitchellh) <a href="https://twitter.com/mitchellh/status/773578346231832576">September 7, 2016</a></blockquote>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
