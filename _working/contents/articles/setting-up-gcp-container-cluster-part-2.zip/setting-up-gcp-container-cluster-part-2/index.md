---
title: Setting up a GCP Container Cluster - Part II
author: Adron Hall
date: 2017-02-01 11:06:11
template: article.jade
---
<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>


Google Container Engine

Container Clusters > https://cloud.google.com/container-engine/docs/clusters/

https://cloud.google.com/container-engine/docs/clusters/operations
