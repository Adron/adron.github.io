---
title: hashiconf trip day 3 part II presentation antics
author: Adron Hall
date: 2016-09-08
template: article.jade
---
<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>
