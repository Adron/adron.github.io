---
title: coding but seriously talk first
author: Adron Hall
date: 2017-09-16 16:47:47
template: article.jade
---
<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>

Coding... But Seriously Talk First!

Let's talk about two things. One, how people ask for software solutions and two, how we build a solution based on what we're asked for. This of course isn't an all encompassing treatment of the topic, that would actually require a large book, or books to thoroughly cover. It would be encyclopedic like in almost every way. For this article I'm going to walk us through a few specific scenarios.

Most software requests come in some form of a verbal description of a problem.
