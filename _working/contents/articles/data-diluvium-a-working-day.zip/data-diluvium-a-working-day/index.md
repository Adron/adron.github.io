---
title: data diluvium a working day
author: Adron Hall
date: 2017-05-17 06:24:14
template: article.jade
---
Today after work and some dinner, I sat down to write some code for the Data Diluvium Project. There's more than a few items to work and hoped to knock out one or two.

As a refresher, here's what I'd written about with regard to the Data Diluvium Project:

* [Data Diluvium Getting Started](http://blog.adron.me/articles/data-diluvium-getting-started/)
* [Data Diluvium Design Ideas](http://blog.adron.me/articles/data-diluvium-design-ideas/)

I gave a quick reread of these myself for a refresher. For a quick review of the next items to work on, I've [kept somewhat of a list]() on Github and also a nice swim lane based kanban @ [waffle.io of work items](https://waffle.io/Adron/datadiluvium).

<span class="more"></span>



<div class="image float-right">
![Streamsets](streamset2.jpg)
</div>
