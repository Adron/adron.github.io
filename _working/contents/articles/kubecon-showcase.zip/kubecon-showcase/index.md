---
title: Post-Keynotes The KubeCon Showcase
author: Adron Hall
date: 2017-12-06 14:10:11
template: article.jade
---
I left the keynote, which ended a little late, with the expectations of attending several of the talks. As fate has it, there were far to many conversations, demos, and tech discusssion awaiting me in the KubeCon Showcase. I didn't make it to the talks after the keynote, but things worked out none the less.

Here's a few of the booths I visited, some photos, and the tech I discussed with a number of people.

<span class="more"></span>

## CNCF Projects

There's an easy to find list of the all the CNCF Projects [here](https://www.cncf.io/projects/).

[![CNCF Projects](CNCF-Projects.png)](https://www.cncf.io/projects/)

The first project listed is Kubernetes itself. This conference (KubeCon) is of course about Kubernetes but I'll skip that one for now. I'll instead aim on the peripheral projects that work with Kubernetes I had discussions about today.

### Project: Fluentd
*Type: Logging*
*Github: https://github.com/fluent/fluentd/*

Fluentd is a log collector. It collects events from various data sources and writes them to files, RDBMS, NoSQL, IaaS, SaaS, Hadoop, and other backends. This provides a way to manage the logging infrastructure under a unified model. Each event that is collected consists of tag, time, and record. Tag is string seperated with a '.' (like mystuff.access or mystuff.security). Time is a UNIX time recorded for the event when it occurred and record is a JSON object, giving one the ability to log a wide arrange of information.

The real paradigm shift of Fluentd and logging data collection really is the consumer change: from human consumers of logging data to machine consumers of logging data.

### Project: Prometheus
*Type: Monitoring*



### Project: Linkerd
*Type: Service Mesh*

### Project: gRPC
*Type: Remote Procedure Call*

### Project: CoreDNS
*Type: Service Discovery*

### Project: CNI
*Type: Networking API*

