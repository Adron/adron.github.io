---
title: what makes good software engineers
author: Adron Hall
date: 2017-09-18 08:17:33
template: article.jade
---
<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>
