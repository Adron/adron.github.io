---
title: I Want a Go CLI
author: Adron Hall
date: 2016-25-10
template: article.jade
---
I sat in seat 20B on United Airlines Flight, enjoying the roominess of the Boeing 777 in service on this route between San Francisco and London.

<span class="more"></span>

<div class="image float-right">
    ![Streamsets](streamset2.jpg)
</div>


CLI in Go
1. https://gobyexample.com/command-line-arguments
2. https://blog.komand.com/build-a-simple-cli-tool-with-golang
3. 
